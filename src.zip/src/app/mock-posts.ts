import{Post} from './Post';
export const Posts:Post[ ]=[
    {
        id:1,
        title:"Blog post title1",
        content:"Sample content......."
    },
    {
        id:2,
        title:"Blog post title2",
        content:"Sample content......."
    },
    {
        id:3,
        title:"Blog post title3",
        content:"Sample content......."
    }
]