import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PostService } from 'src/app/services/post.service';

@Component({
  selector: 'app-edit-post',
  templateUrl: './edit-post.component.html',
  styleUrls: ['./edit-post.component.css']
})
export class EditPostComponent implements OnInit {

  post: any;
  id?:number;
  title?: string;
  content?: string;

  constructor(private postservice: PostService, private route: ActivatedRoute) {}

  ngOnInit(): void {
    

    this.route.paramMap.subscribe((paramMap) => {
      const idParam = paramMap.get('id');
      if (idParam !== null) {
        const postId: number = +idParam;

        
        this.postservice.getPost(postId).subscribe((retrievedPost) => {
          this.id = retrievedPost.id;
          this.title = retrievedPost.title;
          this.content = retrievedPost.content;
        });
      } else {
        
      }
    });
  }

  onSubmit(){
    const updatedPost ={
      id:this.id,
      title:this.title,
      content:this.content
    }
  

  this.postservice.editPost(updatedPost).subscribe();
  }
}
